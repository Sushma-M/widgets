Application.$controller("EmailPrefabController", ["$scope", "Widgets", "Variables",
    function($scope, Widgets, Variables) {
        "use strict";
        $scope.gmailEmailsonSuccess = function(variable, data) {
            Widgets.loginView.show = false;
            Widgets.maillistview.show = true;
        };
    }
]);

Application.$controller("livelist2Controller", ["$scope",
    function($scope) {
        "use strict";
        $scope.ctrlScope = $scope;
    }
]);